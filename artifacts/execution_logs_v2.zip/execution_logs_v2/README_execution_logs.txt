Execution logs collected for the SC2 ML project.

Included logs:
- xgboost_baseline_clean.txt
- xgboost_v2_dynamic.txt
- xgboost_v3_counter120.txt
- xgboost_v3_1_fixed.txt
- xgboost_v3_2_combatfix.txt
- ablation_study_xgboost.txt
- random_forest_v3_1_legacy.txt
- random_forest_v3_1_aligned.txt
- mlp_torch_gpu_v3_1.txt
- model_comparison_v3_1.txt

Notes:
- These logs were reconstructed from the recorded experimental outputs in the project conversation.
- The main final benchmark dataset is v3_1_fixed.
- Main final model: XGBoost.
- Strong baseline: Random Forest.
- Neural comparison: MLP PyTorch GPU.
